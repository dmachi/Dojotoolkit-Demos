dojo.provide("ws.player.livestream");
dojo.require("dojox.widget.FisheyeList");
dojo.require("ws.player.base");

dojo.declare("ws.player.livestream", [ws.player.base], {
	templateString: dojo.cache("ws.player", "template/livestream.html"),
	widgetsInTemplate: true,
	channel: "widespreadconferences",
	devKey: "OaqmIi_k-Q_vJS_DBw5PsWHqdRZL7Sh3DKvZjHc2pszLlalCbCBEyfnRB0cCDesd8FZXczjzQSnmDOyyJX3zUeQWQ2Zybvt8YY0tjvDAs0g",
	autoPlay: true,
	postCreate: function(){
		this.embedFlash();
		//this._timer=settimer(dojo.hitch(this, "timerCallback"),250);
	},

	timerCallback: function(){
		this.playbackPosition = this._player.getTime();
		
	},
	embedFlash: function() {
                var params = { AllowScriptAccess: 'always' };                                   
                var flashvars = { channel: this.channel, devKey: this.devKey};

		livestreamPlayerCallback=dojo.hitch(this, "playerCallback");

		swfobject.embedSWF("http://cdn.livestream.com/chromelessPlayer/wrappers/JSPlayer.swf",
                        this.id+"_livestreamPlayer", "100%", "100%", "9.0.0", "expressInstall.swf", flashvars, params);
		
	},

	playerCallback: function(event){
		if (event == 'ready') {                                                                                         
			this._player = dojo.byId(this.id + "_livestreamPlayer");
			this.onLoad();
		}else{                                                                          
			console.log("Event: ", event);
		}                                                                               
 
	},

	onLoad: function(){
		this._player.setDevKey(this.devKey);
		this._player.showPlayButton(true);
		this._player.showPauseButton(true);
		this._player.showMuteButton(true);
		this._player.showThumbnail(true);
		this._player.showSpinner(true);

		if (this.autoPlay) {
			this.play();
		}
	},

	onClick: function(){
		this._player.stopPlayback();
	},

	onFocusIn: function(){
		console.log("onfocusin");
	},

	onFocusOut: function(){
		console.log("onfocusout");
	},

	play: function(){
		console.log("play()" );
		this._player.startPlayback();
	},
	stop: function(){
		console.log("stop Playback()" );
		this._player.stopPlayback();
	}

});
