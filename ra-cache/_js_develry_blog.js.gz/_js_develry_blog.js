dojo.provide("develry.blog");

dojo.declare("develry.blog", null, {
	init: function(){
		this.inherited(arguments);
		this.log(INFO, "Blog Init");
	}
});


