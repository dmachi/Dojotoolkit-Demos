dojo.provide("ws.registration.utils");

ws.registration.utils = {}
