dojo.provide("ws.Login");

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require('dijit.TooltipDialog');
dojo.require('dijit.form.CheckBox');
dojo.require('dijit.form.DropDownButton');


dojo.declare("ws.Login", [dijit._Widget, dijit._Templated], {
	templateString: dojo.cache("ws", "templates/Login.html"),
	widgetsInTemplate: true,
	registrationLink: "/Page/Register",
	userid: "",
	username: "",

	postCreate: function(){
		console.log("postCreate()");
		//console.log("href: " + window.location.pathname);
		if (window.location.pathname==this.registrationLink){
			this.registerButton.set("disabled", true);
		}

		if (dojo.cookie('wsUsername')){
			console.log("uname cookie: " + dojo.cookie('wsUsername'));
			this.usernameInput.set('value',dojo.cookie('wsUsername'));
		}

		dojo.connect(this.loginButton, "openDropDown", this, function(){
			//console.log("open drop down")
			this._keypressConnect=dojo.connect(this.dialog.domNode, "onkeypress", this, "_keyPress");
		});

		dojo.connect(this.loginButton, "closeDropDown", this, function(){
			//console.log("close drop down")
			if (this._keypressConnect){
				dojo.disconnect(this._keypressConnect);		
			}
		});
		console.log("end postCreate");
	},

	_keyPress: function(e){
		if (e.keyCode == dojo.keys.ENTER) {
			console.log("enter pressed");
			if (this.usernameInput.get('value')&&this.passwordInput.get('value')){
				this.loginButton.closeDropDown();
				this._clickDoLogin();
			}else{
				if (this.usernameInput.get('value')){
					dijit.focus(this.passwordInput);
				}else{
					dijit.focus(this.usernameInput);
				}
			}
		}
	},
	_loginClick: function(e){
		console.log("_loginClick()");
		//this.messageNode.innerHTML="";
		//dojo.stopEvent(e);
	},
	_clickLogout: function(e){
		//console.log("Logout()");
		dojo.stopEvent(e);

		var d = dojo.xhrPost({
			url: "/Class/User",
			handleAs: "json",
			headers: {accept: "*/*"},
			postData: dojo.toJson({"method": "authenticate", params: [null, null],id:'login1'})
		});

		d.addCallback(dojo.hitch(this, function(res){
			//console.log("authenticate results: ", res);
			if (!res || res.error || !res.result){
				throw new Error("LoggingOut");
			}

			if(res.result && res.result.name){
				this.onLogin(res.result);	
			}
		}));

		d.addErrback(dojo.hitch(this, function(err){
			this.onLogout();
		}));
	},
	_clickRegister: function(e){
		console.log("_clickRegister()");
		window.location.href = this.registrationLink;
	},

	_setUsernameAttr: function(name){
		console.log("_setUsernameAttr Name: ", name, "this.username", this.username);
		var msg = "Welcome";
		if (name){
			msg = msg + " " + name;
		}

		this.usernameNode.innerHTML=msg;
	},

	_setUseridAttr: function(uid){
		console.log("_setUseridAttr Name: ", name, "this.username", this.username);
		dojo.attr(this.accountButtonNode, 'href', uid);
	},


	_clickDoLogin: function(e){
		//console.log("_clickDoLogin()")
		if (e){
			dojo.stopEvent(e);
		}

		if ((this.usernameInput.get('value')) && (this.rememberMe.get('checked'))) {
			console.log("Set wsUsername to: ", this.usernameInput.get('value'), this.rememberMe.get('value'));
			dojo.cookie('wsUsername', this.usernameInput.attr('value'));
		}

		var d = dojo.xhrPost({
			url: "/Class/User",
			handleAs: "json",
			headers: {accept: "*/*"},
			postData: dojo.toJson({"method": "authenticate", params: [this.usernameInput.get('value'), this.passwordInput.get('value')], id:"login1"})
		});

		this.passwordInput.set('value', "");
		this.messageNode.innerHTML="";

		d.addCallback(dojo.hitch(this, function(res){
			//console.log("authenticate results: ", res);
			if (!res || res.error || !res.result){
				this.messageNode.innerHTML="Login attempt failed. Please try again.";
				this.loginButton.openDropDown();
			}else if(res.result && res.result.name){
				this.onLogin(res.result);	
			}
		}));

		d.addErrback(dojo.hitch(this, function(err){
			//console.log("error logging in, reset back to logout state");
			//console.warn("Login Failure: ", err);
			this.onLogout()	
		}));
	},


	onLogin: function(user){
		console.log("onLogin: ", user.name, user.id);
		this.set("userid", user.id);
		this.set("username",user.name);
		console.log("dojo.body(): ", dojo.body());
		dojo.addClass(dojo.body(), "loggedIn");
	},

	onLogout: function(){
		this.set("username", null);
		//this.set("userid", null);
		dojo.removeClass(dojo.body(), "loggedIn");
	
	},

	_clickRegister: function(e){
		console.log("_clickRegister()");
		window.location.href = this.registrationLink;
	}
});
