dojo.provide("dojoc.dmachi.kernel.hashNavigation");
dojo.require("dojo.hash");

dojo.declare("dojoc.dmachi.kernel.hashNavigation", null, {
	init: function(){
		this.inherited(arguments);
		this.log(INFO, "hashNavigation init");
		var initHash = dojo.hash();
		if ((!initHash || initHash=="#")&&(this.defaultHash)){
			dojo.hash(this.defaultHash);
		}
		dojo.subscribe("/dojo/hashchange", dojo.hitch(this, "onHashChange"));
	},

	onHashChange: function(rawHash){
		console.log("onHashChange: ", rawHash);
		var hash = rawHash;
		if(hash.charAt(0) == "#"){
			hash = hash.substring(1);
		}

		dojo.query("A[href=" + hash + "]").forEach(function(n){
			var contentLocation = dojo.attr(n, "contentDestination");
			console.log("contentPanes: ",contentLocation,  this.contentPanes);
			var paneId = this.contentPanes[contentLocation];
			console.log("paneId: ", paneId, dijit.byId("paneId"));
			dijit.byId(paneId).attr("href", hash);
		},this);
	}

});


