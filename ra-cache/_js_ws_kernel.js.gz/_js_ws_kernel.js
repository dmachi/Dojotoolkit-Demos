dojo.provide('ws.kernel');
dojo.require('dojoc.dmachi.kernel.base');
dojo.require('dojoc.dmachi.kernel.eventManager');
dojo.require('dojoc.dmachi.kernel.hashNavigation');

dojo.declare('ws.kernel', [dojoc.dmachi.kernel.base,dojoc.dmachi.kernel.eventManager, dojoc.dmachi.kernel.hashNavigation], {
		modules: ["dojoc.dmachi.kernel.eventManager", "dojoc.dmachi.kernel.hashNavigation"],
		logLevel: ERROR | WARN | INFO | DEBUG,
		parseOnLoad: true,
		events: [
			{query: "a[handleAs=dialog]", event: "onclick", action: "launchDialog"},
			{query: "a[handleAs=updateHash]", event: "onclick", action: "updateHash"}
		],
		contentPanes: {main: "leftColumnCP"}
});


