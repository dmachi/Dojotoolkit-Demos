dojo.provide("dojoc.dmachi.kernel.base");

var DEBUG, INFO, WARN, ERROR;

dojoc.dmachi.kernel.log = {};
dojoc.dmachi.kernel.log.DEBUG = DEBUG =  0x1;
dojoc.dmachi.kernel.log.INFO = INFO = 0x2;
dojoc.dmachi.kernel.log.WARN = WARN = 0x4;
dojoc.dmachi.kernel.log.ERROR = ERROR = 0x8;

dojo.declare("dojoc.dmachi.kernel.base", null, {
	// parseOnLoad: Boolean
	//	Trigger the parser after the dom content has loaded
	parseOnLoad: true,
	
	constructor: function(params){
		dojo.mixin(this, params);
		this.init();
	},

	init: function(){
		// summary:
		//	This is the main init method which controls the startup and lifecyle of the kernel

		dojo.addOnLoad(dojo.hitch(this, "onDomContentLoaded"));
	},

	log: function(level/*, args, args*/){
		// summary
		// 	simple logging method.  
		// 	Log level is defined as a bitmask in the config and matching log levels will be ouput
		// 	levels are DEBUG, INFO, WARN, ERROR and the config looks like
		//	logLevel: ERROR | INFO  // note that it is | not ||
		//
		// 	additional custom levels can be defined by adding to the list of bitmasks defined at the 
		//	top of this file. 

		if (arguments.length>1){
			var args = [];
			for(var i=1;i<arguments.length;i++){
				args.push(arguments[i]);
			}
			var id = dojo.config.kernelId || "Kernel";
			if (this.logLevel & level){
				switch(level){
					case WARN:
						console.warn("[" +id+ "]", args);
						break;
					case ERROR:
						console.error("[" + id + "]", args);
						break;
					default:
						console.log("[" + id + "]", args);
						break;
				}				
			}		
		}
	},	

	parseDom: function(){
		// summary
		//	Call the dojo parser and then trigger onParse

		dojo.parser.parse();
		this.onParse();
	},

	onParse: function(){
		// summary
		//	Event called when Parsing is completed.  Triggers the ready() event when completed.
		this.log(DEBUG, "onParse");
		this.ready();
	},
	
	ready: function(){
		// summary 
		//	ready Event, final event when the dom is ready and the widgets have been parsed (if parseOnLoad
		//	is enabled"
		this.log(INFO, "Ready.");
	},

	onDomContentLoaded: function(){
		this.log(DEBUG, "onDomContentLoaded");
		if (this.parseOnLoad){
			dojo['require']("dojo.parser");
			this.parseDom();
		}else{
			this.ready();
		}
	}
});

//Look at the config and launch the kernel
(function(){

	// look for a config on node identify by djConfig.kernelConfigId or "kernel"
	// if the node is found and has inner content, treat that as JSON.  The 
	// resultant object is passed to the kernel as its parameters
	var n = dojo.byId(dojo.config.kernelConfigId || "kernel");
	var config = {};
	if (n){
		var config = n.innerHTML;
		if (config && config.length>3){
			config = dojo.fromJson(config);
			if (config && config.logLevel){
				var lvl;
				dojo.forEach(config.logLevel, function(l){
					lvl |= parseInt(dojoc.dmachi.kernel.log[l]);
					config.logLevel = lvl;
				});
			}
		}
	}

	// create a set of mixins starting with the base kernel mixin followed by
	// any modules defined in the config.  
	var mixins = [dojoc.dmachi.kernel.base];
	if (config && config.modules && config.modules.length>0){
		dojo.forEach(config.modules, function(m){
			// ensure any defined modules are loaded...should be loaded
			// in a layer or otherwise by the dev, this is a safety catch 
			dojo['require'](m);
			mixins.push(dojo.getObject(m));
		});
	}

	//declare the new kernel base class
	var id = dojo.config.kernelId || "kernel";
	dojo.declare("dojoc.dmachi.kernel.kernel", mixins,{});

	//instantiate it!
	dojo.global[id] = new dojoc.dmachi.kernel.kernel(config);
})();
