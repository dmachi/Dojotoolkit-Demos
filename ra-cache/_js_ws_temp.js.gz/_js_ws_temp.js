dojo.provide('ws.temp');

                        function launchStandAlone(w){
                                console.log("LaunchStandAlone Player");
                                var player = dijit.byId("player");
                                var button = dojo.byId("launchButton");
                                var n = player.domNode;
                                var n2 = dijit.byId('sessionTabs').domNode;
                                //this.set("disabled", true);
                                dojo.attr(button, "disabled", true);

                                console.log("player: ", n);
                                var vh = dojo.contentBox(n).h;
                                var ch = dojo.contentBox(n2).h + vh;
                                var a1 = dojo.animateProperty({duration: 600, node: n, properties: {height: {end: 0, unit: "px"}, width: {end: 0, unit: "px"}}, onEnd: function(){
                                        console.log("Player: ", player);
                                        player.stop();
                                        player.destroy();
                                        dojo.style(n, "display", "none")
                                }});

                                var a2 = dojo.animateProperty({duration: 600, node: n2, properties: {height: {end: ch, unit: "px"}},onEnd: function(){dijit.byId('sessionTabs').resize()}});
                                var a3 = dojo.animateProperty({duration: 600, node: button, properties: {opacity: {end: 0}},onEnd: function(){ dojo.destroy(button); }});
                                var combined = dojo.fx.combine([a1, a2,a3]);
                                window.open("standalone.html","Widespread Conferences Standalone Video Player", "width=640,height=480,resizable=1,directories=0,copyhistory=0,left=300px");
                                combined.play();
                        }

                        function launchChat() {
                                console.log("launchChat()");
                                var chatpanel = dijit.byId('chat');
                                var nick = dijit.byId("nickname").get('value');
                                var iframe = '<iframe style="width:100%;height: 100%;margin: 0px;padding:0px;border:0px;" src="http://widget.mibbit.com/?settings=6416e1cca777fcc2a341e62aa17d38aa&server=irc.mibbit.net&channel=%23dojo_connect&autoconnect=true&nick=' + nick + '"></iframe>';
                                console.log('iframe' , iframe);
                                chatpanel.set('content', iframe);
                        }

