dojo.provide("dojoc.dmachi.kernel.eventManager");
dojo.require('dojo.hash');

dojo.declare("dojoc.dmachi.kernel.eventManager", null, {
	init: function(){
		this.inherited(arguments);
		this._documentConnects= {};
	},
	onParse: function(){
		this.log("eventManager onParse()");
		dojo.forEach(this.events, this._attachEvent, this);
		this.inherited(arguments);
	},
	_attachEvent: function(evt){
		if (!evt.event){
			this.log(WARN, "Undefined event property in kernel eventManager: ", evt);
			return;
		}

		if(this._documentConnects[evt.event]){
			this.log(DEBUG, "Already Connected to ", evt.event)
			return;
		}
		console.log("_attachingEvent");
		this._documentConnects[evt.event]=dojo.connect(dojo.doc, evt.event, this, "handleDocumentEvents");
	},

	handleDocumentEvents: function(evt){
		//dojo.stopEvent(evt);
		console.log("handleDocumentEvents", evt, evt.currentTarget);
		if (!evt.currentTarget){this.log(DEBUG, "handleDocumentEvents() Skipping Event", evt);return;}
		var target = evt.target;
		dojo.forEach(this.events, dojo.hitch(this, "processEvent",evt, target));
	},

	processEvent: function(evt, target, def){
		console.log("processEvent, evt: ", evt, def);
		if (dojo.query(def.query).some(function(node){console.log("node: ",node, "target: ", target, node==target);return node==target})){
			this.executeEvent(evt, target, def);
		}
	},

	executeEvent: function(evt, target, def){
		console.log("executeEvent: ", evt,evt.action);
		var handleAs = dojo.attr(target, "handleAs");
		switch(handleAs){
			case "dialog":
				dojo.stopEvent(evt);
				this.log(DEBUG, "Launch Dialog Handler");
				var dialog = this.dialog || "dialog";
				if(typeof dialog == 'string'){
					dialog=dijit.byId(dialog);
				}

				dialog.attr("href", dojo.attr(target, "href"));
				dialog.show();
				break;
			case "updateHash":
				dojo.stopEvent(evt);
				var newHash = "#" + dojo.attr(target, "href");

				this.log(DEBUG, "Hash Navigation Handler", newHash);
				dojo.hash(newHash);
				break;
			default:
				this.log(DEBUG, "Unknown Handler, skipping: ", handleAs, def, evt);
		}		
	}


});


