dojo.provide("ws.player.base");
dojo.require("dijit._Widget");
dojo.require("dijit._Templated");

dojo.declare("ws.player.base", [dijit._Widget, dijit._Templated],{
	popout: function(){
		console.log("Popout Player Here");
	}
});
